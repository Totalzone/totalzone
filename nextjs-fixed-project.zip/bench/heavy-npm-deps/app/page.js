import { LodashComponent } from '../components/lodash'
// import { MantineComponent } from "../components/mantine";
// import { MermaidComponent } from "../components/mermaid";

export default function Page() {
  return (
    <>
      {/* <MantineComponent /> */}
      {/* <MermaidComponent /> */}
      <LodashComponent />
    </>
  )
}
