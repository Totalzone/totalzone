'use client'
import * as Lodash from 'lodash-es'

console.log(Lodash)

export function LodashComponent() {
  return (
    <>
      <h1>Client Component</h1>
    </>
  )
}
