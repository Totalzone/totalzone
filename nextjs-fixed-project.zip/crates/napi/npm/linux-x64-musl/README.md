# `@next/swc-linux-x64-musl`

This is the **linux-x64-musl** binary for `@next/swc`
