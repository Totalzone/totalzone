# `@next/swc-linux-arm64-gnu`

This is the **linux-arm64-gnu** binary for `@next/swc`
