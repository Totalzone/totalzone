# `@next/swc-linux-arm64-musl`

This is the **linux-arm64-musl** binary for `@next/swc`
