# `@next/swc-win32-arm64-msvc`

This is the **win32-arm64-msvc** binary for `@next/swc`
