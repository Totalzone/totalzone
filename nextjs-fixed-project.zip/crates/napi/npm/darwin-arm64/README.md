# `@next/swc-darwin-arm64`

This is the **aarch64-apple-darwin** binary for `@next/swc`
