export default function () {
  return null
}

// prettier-ignore
'use client'
