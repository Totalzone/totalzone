export const runtime = 'edge'
export const dynamic = 'force-dynamic'
export const dynamicParams = false
export const fetchCache = 'force-no-store'
export const revalidate = 1
