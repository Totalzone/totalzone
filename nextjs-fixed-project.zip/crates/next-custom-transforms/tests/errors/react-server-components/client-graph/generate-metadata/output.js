export function generateMetadata() {}
export default function() {
    return null;
}
