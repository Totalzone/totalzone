export function getStaticProps() {}

export default function () {
  return null
}
