// This is a comment.
'use strict';
/**
 * This is a comment.
 */ import 'client-only';
export default function() {
    return null;
}
