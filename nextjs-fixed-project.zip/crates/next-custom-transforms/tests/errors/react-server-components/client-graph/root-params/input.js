// This is a comment.

'use strict'

/**
 * This is a comment.
 */

import { unstable_rootParams } from 'next/server'

export default function () {
  return null
}
