export const metadata = {}

export default function () {
  return null
}
