export const metadata = {}

export function generateMetadata() {}

export function getServerSideProps() {}

export default function () {
  return null
}
