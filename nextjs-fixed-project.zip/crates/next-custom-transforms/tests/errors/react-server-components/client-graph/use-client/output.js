import 'react';
export default function() {
    return null;
}
