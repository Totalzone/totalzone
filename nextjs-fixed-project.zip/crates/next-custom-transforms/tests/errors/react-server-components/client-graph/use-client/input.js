import 'react'

// prettier-ignore
'use client'

export default function () {
  return null
}
