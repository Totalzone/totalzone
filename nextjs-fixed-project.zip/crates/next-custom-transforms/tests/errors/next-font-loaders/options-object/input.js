import { ABeeZee } from '@next/font/google'

const a = fn({ 10: 'hello' })
const a = ABeeZee({ 10: 'hello' })

const a = fn({ variant: [i1] })
const a = ABeeZee({ variant: [i1] })

const a = fn({ variant: () => {} })
const a = ABeeZee({ variant: () => {} })

const a = fn({ ...{} })
const a = ABeeZee({ ...{} })
