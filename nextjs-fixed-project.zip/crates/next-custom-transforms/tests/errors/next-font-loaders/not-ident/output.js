const { a  } = Inter({
    variant: '400'
});
const [b] = Inter({
    variant: '400'
});
const { e  } = {};
