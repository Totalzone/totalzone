import React from 'react'
import { Abel, Inter } from '@next/font/google'

export let firaCode = Abel()
export var inter = Inter()
