import { Inter } from '@next/font/google'

var i = 10
var inter1 = Inter({
  variant: '400',
})

var i2 = 20
let inter2 = Inter({
  variant: '400',
})
