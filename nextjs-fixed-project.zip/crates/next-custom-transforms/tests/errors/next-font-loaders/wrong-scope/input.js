import { Aladin } from '@next/font/google'

Aladin({})

let b
const a = (b = Aladin({ variant: '400' }))

function Hello() {
  const a = Aladin({
    variant: '400',
  })
}

class C {
  constructor() {
    Aladin({
      variant: '400',
    })
  }
}

{
  Aladin({})
}
