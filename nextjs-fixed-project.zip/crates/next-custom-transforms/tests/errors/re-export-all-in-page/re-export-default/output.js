export { default, getStaticProps, getStaticPaths } from './other-page';
