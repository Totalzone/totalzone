export async function getStaticPaths() {}
export const getServerSideProps = function getServerSideProps() {}
