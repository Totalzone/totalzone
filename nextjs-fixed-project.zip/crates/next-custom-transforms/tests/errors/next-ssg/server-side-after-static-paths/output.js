export var __N_SSG = true;
export const getServerSideProps = function getServerSideProps() {
}
