export { a as getServerSideProps } from './input'
export { getStaticPaths } from 'a'
