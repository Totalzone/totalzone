export { getStaticProps, getServerSideProps }
