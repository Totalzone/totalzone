const getStaticProps = async () => {}
export { a as getServerSideProps }
