fn main() {
    turbo_tasks_build::generate_register();
}
