use turbo_tasks_build::generate_register;

fn main() {
    generate_register();
}
