pub(crate) mod page_entry;

pub use page_entry::create_page_ssr_entry_module;
