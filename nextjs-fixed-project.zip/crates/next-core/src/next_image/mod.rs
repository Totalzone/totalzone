pub(crate) mod module;
pub(crate) mod source_asset;

pub use module::StructuredImageModuleType;
